// webcomponent.js
import React from 'react';
import ReactDOM from 'react-dom/client';
import reactToWebComponent from 'react-to-webcomponent';
import WhatsAppWidget from './WhatsAppWidget.jsx';

const WaComp = reactToWebComponent(WhatsAppWidget, React, ReactDOM);
customElements.define('wa-widget', WaComp);
