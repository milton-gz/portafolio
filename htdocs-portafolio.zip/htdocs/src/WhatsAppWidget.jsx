// WhatsAppWidget.jsx
import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

/*
 Props:
  - baseUrl: URL base de tu backend (widget hará POST a `${baseUrl}/chat`)
  - editableConfigUrl: (opcional) URL pública de JSON o Google Sheets CSV publicada
  - width, height: tamaño del panel
  - avatarIcons: array de URLs (SVG/PNG) para rotar en avatar animado
*/

const defaultDescriptions = [
  {
    text: `hoy casi me acuesto molesto
y le pregunte a mi almohada
si no servira de nada todo lo que soñe y soñe`,
    album: 'Vida',
    albumCover: 'https://via.placeholder.com/400x400?text=Vida+album'
  },
  {
    text: `desde la cuna hasta la tumba
una guerra en el planeta de agua llamado tierra`,
    album: 'Give Me 5 / Another Five',
    albumCover: 'https://via.placeholder.com/400x400?text=Give+Me+5'
  },
  {
    text: `Quieren escupime pero yo estoy muy arriba
y si escupes pa arriba en la cara te cae saliva`,
    album: 'Can+Zoo Índigos',
    albumCover: 'https://via.placeholder.com/400x400?text=Can+Zoo+Indigos'
  },
  'Desarrollador Web • Milton Gutierrez',
  'Front-end • React • UX'
];

export default function WhatsAppWidget({
  baseUrl = '/api',
  editableConfigUrl = '',
  width = 720,
  height = 540,
  initialOpen = false,
  avatarIcons = [
    'https://cdn.simpleicons.org/visualstudiocode',
    'https://cdn.simpleicons.org/linux',
    'https://cdn.simpleicons.org/kali-linux',
    'https://cdn.simpleicons.org/archlinux',
    'https://cdn.simpleicons.org/microsoftoffice',
    'https://cdn.simpleicons.org/php',
    'https://cdn.simpleicons.org/python',
    'https://cdn.simpleicons.org/mysql',
    'https://cdn.simpleicons.org/html5',
    'https://cdn.simpleicons.org/css3'
  ],
  rotateIntervalMs = 5000,
  avatarCycleMs = 1200,
  fetchTimeoutMs = 15000
}) {
  const [open, setOpen] = useState(initialOpen);
  const [messages, setMessages] = useState([{ id: 'sys-1', who: 'bot', text: 'Hola 👋 — escribe algo para probar el chat' }]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [descIndex, setDescIndex] = useState(0);
  const [remoteDescriptions, setRemoteDescriptions] = useState(null);
  const [iconIndex, setIconIndex] = useState(0);
  const bodyRef = useRef(null);
  const sessionId = useRef('widget-session-' + Date.now());

  // Cargar config remota (JSON o CSV publicado desde Google Sheets)
  useEffect(() => {
    if (!editableConfigUrl) return;
    (async () => {
      try {
        const r = await fetch(editableConfigUrl, { cache: 'no-cache' });
        const ct = r.headers.get('content-type') || '';
        if (ct.includes('application/json')) {
          const cfg = await r.json();
          if (cfg.descriptions) setRemoteDescriptions(cfg.descriptions);
          return;
        }
        // CSV (Sheets published) -> parse básico
        const txt = await r.text();
        if (txt && txt.includes(',')) {
          const rows = txt.trim().split('\n').map(row => row.split(','));
          const header = rows.shift().map(h => h.trim().toLowerCase());
          const descs = rows.map(cols => {
            const obj = {};
            header.forEach((h, i) => obj[h] = (cols[i] || '').trim());
            return obj.albumcover ? { text: obj.text, albumCover: obj.albumcover, album: obj.album } : (obj.text || '');
          });
          setRemoteDescriptions(descs);
        }
      } catch (e) {
        console.warn('No remote config loaded', e);
      }
    })();
  }, [editableConfigUrl]);

  const descriptions = remoteDescriptions || defaultDescriptions;

  // Rotar descripciones
  useEffect(() => {
    const t = setInterval(() => setDescIndex(i => (i + 1) % descriptions.length), rotateIntervalMs);
    return () => clearInterval(t);
  }, [descriptions, rotateIntervalMs]);

  // Rotar iconos avatar
  useEffect(() => {
    const t = setInterval(() => setIconIndex(i => (i + 1) % avatarIcons.length), avatarCycleMs);
    return () => clearInterval(t);
  }, [avatarIcons, avatarCycleMs]);

  // scroll al final
  useEffect(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [messages, typing]);

  // fetch con timeout
  async function fetchWithTimeout(url, options = {}, timeout = fetchTimeoutMs) {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
      const res = await fetch(url, { ...options, signal: controller.signal });
      return res;
    } finally {
      clearTimeout(id);
    }
  }

  async function sendMessage(text) {
    const id = 'm-' + Date.now();
    setMessages(m => [...m, { id, who: 'me', text }]);
    setInput('');
    setTyping(true);
    setMessages(m => [...m, { id: 'typing', who: 'bot', text: 'Escribiendo...' }]);

    try {
      const res = await fetchWithTimeout(`${baseUrl}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: text, sessionId: sessionId.current })
      });

      if (!res.ok) {
        const body = await res.text();
        setMessages(m => m.filter(x => x.id !== 'typing'));
        setMessages(m => [...m, { id: 'err-' + Date.now(), who: 'bot', text: `Error del servidor: ${res.status} ${res.statusText}` }]);
        console.error('Backend error', res.status, body);
        return;
      }

      // Intentar parsear JSON
      const j = await res.json();
      setMessages(m => m.filter(x => x.id !== 'typing'));
      setMessages(m => [...m, { id: 'r-' + Date.now(), who: 'bot', text: j.answer || 'No obtuve respuesta.' }]);
    } catch (e) {
      setMessages(m => m.filter(x => x.id !== 'typing'));
      if (e.name === 'AbortError') setMessages(m => [...m, { id: 'err-' + Date.now(), who: 'bot', text: 'Tiempo de espera agotado' }]);
      else { setMessages(m => [...m, { id: 'err-' + Date.now(), who: 'bot', text: 'Error de conexión' }]); console.error(e); }
    } finally {
      setTyping(false);
    }
  }

  function vizStyleForText(text = '') {
    const t = (text || '').toLowerCase();
    if (t.includes('vida')) return { background: 'linear-gradient(135deg,#fff1c2,#ffd6a5)', color: '#000' };
    if (t.includes('tumba') || t.includes('muerte')) return { background: 'linear-gradient(135deg,#111827,#374151)', color: '#fff' };
    if (t.includes('arriba') || t.includes('subir')) return { background: 'linear-gradient(135deg,#e0f2fe,#bae6fd)', color: '#000' };
    return { background: '#fff', color: '#000' };
  }

  const currentDesc = descriptions[descIndex];

  return (
    <div style={{ position: 'fixed', right: 24, bottom: 24, zIndex: 99999, fontFamily: 'Inter, system-ui, Arial' }}>
      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <button aria-label="Abrir chat" onClick={() => setOpen(o => !o)} style={{ width: 64, height: 64, borderRadius: 9999, background: 'linear-gradient(135deg,#06b6d4,#3b82f6)', border: 'none', boxShadow: '0 12px 30px rgba(2,6,23,0.2)', cursor: 'pointer' }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" style={{ display: 'block', margin: 'auto' }}><path d="M21 11.5A8.5 8.5 0 1 1 6.5 4" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }} transition={{ type: 'spring', stiffness: 300, damping: 24 }} style={{ width, height, background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 12px 40px rgba(2,6,23,0.18)', display: 'flex', marginTop: 12 }}>
            {/* Chat side */}
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
              <div style={{ padding: 14, borderBottom: '1px solid #eee', display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 44, height: 44, borderRadius: 9999, overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <img src={avatarIcons[iconIndex]} alt="icon" style={{ width: 36, height: 36 }} />
                </div>
                <div style={{ lineHeight: 1 }}>
                  <div style={{ fontWeight: 700 }}>Milton Dev</div>
                  <div style={{ fontSize: 12, color: '#666' }}>Soporte & Portfolio — Bot</div>
                </div>
              </div>

              <div ref={bodyRef} style={{ padding: 16, background: '#fafafa', flex: 1, overflowY: 'auto' }}>
                {messages.map(m => (
                  <div key={m.id} style={{ display: 'flex', marginBottom: 10, justifyContent: m.who === 'me' ? 'flex-end' : 'flex-start' }}>
                    <div style={{ maxWidth: '78%', padding: '10px 14px', borderRadius: 12, background: m.who === 'me' ? 'linear-gradient(90deg,#06b6d4,#3b82f6)' : '#fff', color: m.who === 'me' ? '#fff' : '#111', boxShadow: '0 1px 2px rgba(0,0,0,0.03)' }}>
                      <div style={{ whiteSpace: 'pre-wrap' }}>{m.text}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ padding: 12, borderTop: '1px solid #eee', display: 'flex', gap: 8 }}>
                <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && input.trim()) sendMessage(input.trim()); }} placeholder="Escribe tu mensaje..." style={{ flex: 1, padding: '10px 12px', borderRadius: 8, border: '1px solid #ddd' }} />
                <button onClick={() => input.trim() && sendMessage(input.trim())} style={{ padding: '10px 14px', borderRadius: 8, border: 'none', background: 'linear-gradient(135deg,#06b6d4,#3b82f6)', color: '#fff' }}>Enviar</button>
              </div>
            </div>

            {/* Profile / info side */}
            <div style={{ width: '44%', minWidth: 280, borderLeft: '1px solid #f0f0f0', display: 'flex', flexDirection: 'column', alignItems: 'center', padding: 18, gap: 12, ...vizStyleForText(typeof currentDesc === 'object' ? currentDesc.text : (currentDesc || '')) }}>
              <div style={{ width: 180, height: 180, borderRadius: 16, overflow: 'hidden', boxShadow: '0 8px 24px rgba(2,6,23,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ width: 140, height: 140, borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f7fafc' }}>
                  <img src={avatarIcons[iconIndex]} alt="avatar large icon" style={{ width: 100, height: 100 }} />
                </div>
              </div>

              <div style={{ textAlign: 'center' }}>
                <div style={{ fontWeight: 700, fontSize: 16 }}>Milton Gutierrez</div>
                <div style={{ fontSize: 13, color: '#666', marginTop: 6 }}>{typeof currentDesc === 'string' ? currentDesc : currentDesc.text}</div>
              </div>

              {typeof currentDesc === 'object' && currentDesc.albumCover && (
                <div style={{ width: '100%', marginTop: 8, display: 'flex', justifyContent: 'center' }}>
                  <img src={currentDesc.albumCover} alt="Album cover" style={{ width: 160, height: 160, objectFit: 'cover', borderRadius: 8, boxShadow: '0 8px 24px rgba(0,0,0,0.08)' }} />
                </div>
              )}

              <div style={{ width: '100%', marginTop: 8 }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Resumen</div>
                <div style={{ fontSize: 13, color: '#444', lineHeight: 1.4 }}>
                  Desarrollo web fullstack. Soporte técnico y mantenimiento. Proyectos: tienda online, landing pages, dashboards.
                </div>
              </div>

              <div style={{ width: '100%', marginTop: 'auto' }}>
                <a href="/portfolio" target="_blank" rel="noreferrer" style={{ display: 'inline-block', width: '100%', textAlign: 'center', padding: '10px 12px', borderRadius: 8, background: '#0ea5a4', color: '#fff', textDecoration: 'none', fontWeight: 600 }}>Ver portafolio</a>
                <a href="https://wa.me/503XXXXXXXXX" target="_blank" rel="noreferrer" style={{ display: 'block', width: '100%', textAlign: 'center', padding: '10px 12px', borderRadius: 8, marginTop: 8, background: '#06b6d4', color: '#fff', textDecoration: 'none', fontWeight: 600 }}>Contactar por WhatsApp</a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
